centos 6.5	 
	 
rabbitmq 无网络安装：
防火墙 添加端口：
vi /etc/sysconfig/iptables
#RabbitMQ
-A INPUT -m state --state NEW -m tcp -p tcp --dport 15672 -j ACCEPT
-A INPUT -m state --state NEW -m tcp -p tcp --dport 25672 -j ACCEPT
-A INPUT -m state --state NEW -m tcp -p tcp --dport 5672 -j ACCEPT
-A INPUT -m state --state NEW -m tcp -p tcp --dport 4369 -j ACCEPT
-A INPUT -m state --state NEW -m tcp -p tcp --dport 5671 -j ACCEPT
 
#RabbitMQ

然后重启防火墙 ：service iptables restart

rpm -ivh socat-1.7.3.2-2.el7.x86_64.rpm --nodeps
rpm -ivh erlang-21.3.3-1.el6.x86_64.rpm

rpm -ivh rabbitmq-server-3.7.14-1.el6.noarch.rpm
 开启服务 ：service rabbitmq-server start
开启控制台管理插件：rabbitmq-plugins enable rabbitmq_management
添加用户 ：rabbitmqctl add_user admin 123456
赋予角色 : rabbitmqctl set_user_tags admin administrator

